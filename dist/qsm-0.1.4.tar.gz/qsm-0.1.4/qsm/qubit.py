from qsm.gate import *
from qsm.core import *
gen_qubit = qubit