import numpy as np

class Instruction:
    def __init__(self, matrix):
        self.matrix = matrix